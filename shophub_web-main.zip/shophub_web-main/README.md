# my-kirana-store
**( A dsa and OOPs based project in c++ language )**

**Introduction**

In this we are going to design and implement a program that can be used in E-commerce industries and daily needs of retails store or vendors which 
will help administration and customer to buy, sell of product or add the new product along with deletion and the product which has shortage or less demanded
or have high demand in market etc. 

**Motivation**

As the technology is developing at a fast pace and everyone is getting shifting online to buy products ,( also due to covid guidelines ) so this application will help both administration to customer to manage their product details along with their personal details. 

**Description**

So, in this project we are going to develop the following features : 
• So with the help of Linked List and stack in the administration 
portal the admin can add , display or modify the existing 
product. 
• Also with some features of deletion, customer list, deque 
customer. 
• In customer portal taking trolie, buy something and entering 
name of queue with the help of stack , array and queue. 
• Exiting the program along with about us who are the developer 
of the application. 

**Conclusion**
So, in overall scenario we will going to use Data Structure along with some Object Oriented Programming with some new header files along with c++ fundamentals that our respected university teacher had taught us in our classes and to help society by creating such application with our current knowledge. 
